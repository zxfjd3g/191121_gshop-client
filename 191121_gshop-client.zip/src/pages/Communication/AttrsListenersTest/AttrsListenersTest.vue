<template>
  <div>
    <h2>自定义带Hover提示的按钮</h2>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'AttrsListenersTest',

    methods: {
      
    },
  }
</script>
