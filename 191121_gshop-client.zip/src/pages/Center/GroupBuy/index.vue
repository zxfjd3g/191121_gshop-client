<template>
  <div>
    <h2>GroupBuy</h2>
    <h2>GroupBuy</h2>
    <h2>GroupBuy</h2>
    <h2>GroupBuy</h2>
    <h2>GroupBuy</h2>
    <h2>GroupBuy</h2>
  </div>
</template>

<script>
export default {
  name: 'GroupBuy',
}
</script>

<style lang="less" scoped>

</style>
