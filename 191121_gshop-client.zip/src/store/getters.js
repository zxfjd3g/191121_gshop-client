export default {
  test (state) { // 总的state

  }
}